==========================================================
LABORATORIUM MAYA IPAS — ROTASI DAN REVOLUSI BUMI
Laboratorium Sains Digital Interaktif SD Kelas VI (Offline)
==========================================================

CARA MENGGUNAKAN
1. Ekstrak (unzip) seluruh berkas ini ke satu folder.
2. Buka file "index.html" dengan peramban (Chrome/Edge/Firefox).
   - Disarankan: klik dua kali index.html, atau
   - Chrome/Edge: klik kanan index.html > Open with > Google Chrome.
3. Di halaman pembuka, KLIK PLANET BUMI dulu (di sisi kanan,
   tepat di bawah tulisan "KLIK BUMI UNTUK MEMULAI") — narasi
   sambutan dan musik latar mulai terdengar, lalu tombol MULAI
   dan CARA MENGGUNAKAN muncul.
4. Setelah masuk beranda, jelajahi ruang-ruang laboratorium:
   Galeri Tata Surya, Lab Rotasi, Lab Revolusi, Lab Zona Waktu,
   Lab Pergantian Musim, Ruang Eksperimen (5 percobaan),
   Evaluasi, dan Refleksi.
5. Untuk pengalaman terbaik di Interactive Flat Panel (IFP)
   atau proyektor, gunakan tombol Layar Penuh di pojok kanan
   atas.
6. Tombol dengan ikon BALON PERCAKAPAN + PANAH PUTAR di pojok
   kanan atas berfungsi untuk MENGULANGI narasi halaman yang
   sedang dibuka (tersedia di semua ruang). Ikon pengeras suara
   di sebelahnya membuka Pengaturan Suara (volume musik, efek,
   dan narasi — perubahan volume narasi langsung terasa).

STRUKTUR MENU
- BERANDA: kartu Galeri Tata Surya, Lab 01-04, Ruang Eksperimen,
  Evaluasi, Refleksi + panel progres kunjungan dan skor terbaik.
- GALERI TATA SURYA: model 3D Matahari + 8 planet + Bulan;
  klik objek (di layar atau daftar) untuk informasi;
  Mode Perbandingan Ukuran; kontrol putar/jeda, label, garis
  orbit, kecepatan.
- LAB 01 ROTASI BUMI: Bumi 3D + poros + panah arah + Matahari;
  kontrol Putar/Jeda, Reset, kecepatan (jam/detik), garis sumbu,
  panah arah, Mode Ikuti Jakarta, preset jam; HUD jam simulasi,
  status SIANG/MALAM pengamat Jakarta, kompas gerak semu
  Matahari (terbit timur -> tengah hari -> terbenam barat).
- LAB 02 REVOLUSI BUMI: Matahari di titik fokus, orbit elips,
  label 12 bulan, penanda PERIHELION (Januari) dan APHELION
  (Juli), garis jarak; kontrol Putar/Jeda, kecepatan
  (hari/detik), penggeser posisi, chip bulan, toggle
  orbit/label/jarak; informasi posisi & jarak mengikuti Bumi.
- LAB 03 ZONA WAKTU: bola Bumi 3D dengan garis bujur tiap 15
  (khatulistiwa dan Greenwich ditandai) + peta Indonesia
  WIB/WITA/WIT (klik kota) + jam digital kota terpilih +
  4 jam pembanding (London, Jakarta, Denpasar, Jayapura);
  penggeser waktu simulasi; penjelasan 360 derajat / 24 jam =
  15 derajat per jam.
- LAB 04 PERGANTIAN MUSIM: Bumi bersumbu miring tetap arahnya
  berevolusi + sinar Matahari; pilih bulan (12 chip / slider /
  putar), sudut pandang Utara-Selatan; meter penerimaan sinar
  kedua belahan; musim per bulan sesuai buku (Des/Mar/Jun/Sep)
  + kartu peringatan miskonsepsi (musim bukan karena jarak!).
- RUANG EKSPERIMEN VIRTUAL (5 percobaan, masing-masing dengan
  tujuan, petunjuk, alat virtual, kontrol, hasil pengamatan,
  dan tombol kesimpulan):
  1) Model Matahari-Bumi-Bulan (3D, sudut Bulan + putar Bumi)
  2) Simulasi Siang-Malam (3D, senter + bola Bumi + miniatur
     orang — seperti kegiatan buku)
  3) Jam Matahari (2D, gerak Matahari + bayangan pensil +
     tombol Tandai Bayangan)
  4) Pengamatan Fase Bulan (klik posisi Bulan; pandangan dari
     Bumi dengan sisi terang menghadap Matahari)
  5) Pengamatan Pergantian Musim (diagram orbit interaktif +
     meter sinar kedua belahan)
- EVALUASI: 15 soal bervariasi (pilihan ganda, benar-salah,
  menjodohkan, melengkapi pernyataan, memilih bagian gambar,
  identifikasi fenomena dari ilustrasi, soal berbasis hasil
  simulasi) dengan umpan balik per soal, skor + bintang,
  pembahasan lengkap, tombol ulangi, dan tombol Refleksi.
- REFLEKSI: 5 pertanyaan + pilihan perasaan + catatan;
  tersimpan lokal dan kosong kembali setiap aplikasi dibuka
  (jurnal per sesi belajar).
- INFORMASI (sidebar bawah): Petunjuk (kartu langkah),
  Kredit & Referensi, dan Pengembang.

FITUR
- Narasi suara Bahasa Indonesia di setiap halaman (tombol
  ikon gelombang suara untuk mengulang; berbunyi otomatis
  sekali per sesi); narasi berhenti otomatis saat pindah
  halaman sehingga tidak bertumpuk.
- Musik latar ambient bertema laboratorium angkasa, efek
  suara interaktif; pengaturan volume musik/efek/narasi +
  tombol mute semua (ikon pengeras suara).
- Seluruh simulasi 3D dapat diseret untuk memutar sudut
  pandang dan di-zoom (roda tetikus / cubitan dua jari).
- Layar penuh untuk IFP/proyektor; penyimpanan lokal hasil
  refleksi, progres kunjungan, dan skor terbaik (localStorage).
- Arah rotasi, sumbu, garis bujur, bulan, dan musim ditampilkan
  sesuai materi buku; angka pengayaan di luar buku ditandai *.

KOMPATIBILITAS
- IFP, laptop, PC: otomatis menyesuaikan layar (panggung 16:9).
- Tablet & HP: gunakan dalam posisi mendatar (landscape); bila
  perangkat tegak (portrait) akan muncul permintaan memutar
  layar.
- Semua fitur berjalan 100% offline: model 3D, tekstur, font,
  musik, efek suara, dan narasi tersimpan lokal di folder ini.
- Tautan YouTube/TikTok/Instagram di halaman Pengembang
  memerlukan koneksi internet (dinyatakan di halaman itu).

STRUKTUR FOLDER
  index.html          - halaman utama aplikasi
  css/                - gaya tampilan (laboratorium futuristik)
  js/                 - logika aplikasi + Three.js lokal (3D)
  assets/img/textures/- tekstur Bumi/Bulan/Matahari (prosedural)
  assets/fonts/       - font Orbitron, Rajdhani, Nunito (SIL OFL)
  assets/icons/       - favicon SVG
  assets/dev/         - foto pengembang
  audio/music/        - musik latar (sintesis orisinal)
  audio/sfx/          - efek suara (sintesis orisinal)
  audio/narasi/       - narasi suara (TTS AI id-ID-ArdiNeural)
  script_narasi/      - teks lengkap setiap narasi (dokumentasi)

KREDIT & REFERENSI
Diadaptasi dari buku: Amalia Fitri, Ati Haviati Oktora,
Ekatannia Tresnasari, dan Maria Jeanindya Wahyudi. (2025).
Ilmu Pengetahuan Alam dan Sosial untuk SD/MI Kelas VI.
Kementerian Pendidikan Dasar dan Menengah Republik Indonesia.
ISBN 978-634-00-2164-6 — Bab 6: Mengembara di Jagat Raya.
Teks referensi ini juga tersedia di dalam aplikasi pada
halaman "KREDIT & REFERENSI".

PENGEMBANG
Titik Ambarwati, S.Pd. — SD Negeri 1 Petuguran
(Guru & Pengembang Media Pembelajaran)
YouTube / TikTok / Instagram: @bugurutitik

CATATAN
- Narasi menggunakan rekaman suara TTS AI bahasa Indonesia
  (id-ID-ArdiNeural); teks dinamis yang belum terekam memakai
  suara perangkat bila tersedia (Web Speech, prioritas id-ID);
  bila tidak tersedia, narasi senyap dan aplikasi tetap berjalan.
- Bentuk elips orbit pada Lab Revolusi diperbesar agar jelas
  terlihat; jarak nyata ditampilkan pada panel (data pengayaan).
- Hasil refleksi dan skor tersimpan di penyimpanan lokal
  peramban pada perangkat masing-masing (tidak terkirim ke
  internet).
- Bila suara tidak terdengar: periksa Pengaturan Suara (ikon
  pengeras suara) dan pastikan volume perangkat aktif; klik
  sekali di mana pun agar peramban mengizinkan audio.
